-- =====================================================================
--  ООО «ВелосипедДрайв» — схема базы данных
--  Демонстрационный экзамен 09.02.07, вариант 2, 2026
--  СУБД: SQLite 3
--
--  Нормализация: 3НФ. Обеспечена ссылочная целостность (внешние ключи).
--  Все справочные (повторяющиеся) значения вынесены в отдельные таблицы.
--  Схема именования: snake_case, единый стиль для всех объектов.
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ------------------------- Справочники -------------------------------

-- Роли пользователей: Администратор, Менеджер, Авторизированный клиент
CREATE TABLE role (
    role_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE
);

-- Категории товаров (выпадающий список в форме товара)
CREATE TABLE category (
    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE
);

-- Поставщики (выпадающий список в форме товара)
CREATE TABLE supplier (
    supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE
);

-- Производители
CREATE TABLE manufacturer (
    manufacturer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE
);

-- Единицы измерения (шт. и т.п.)
CREATE TABLE unit (
    unit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE
);

-- Статусы заказа: Новый, Завершен
CREATE TABLE order_status (
    status_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL UNIQUE
);

-- Пункты выдачи. ID сохраняем явно (1..36) — заказы ссылаются по номеру строки.
CREATE TABLE pickup_point (
    pickup_point_id INTEGER PRIMARY KEY,
    address         TEXT NOT NULL
);

-- ----------------------- Пользователи --------------------------------

CREATE TABLE app_user (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    role_id       INTEGER NOT NULL,
    full_name     TEXT    NOT NULL,
    login         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    FOREIGN KEY (role_id) REFERENCES role(role_id)
);

-- -------------------------- Товары -----------------------------------
-- product_id — числовой суррогатный ключ: не показывается при добавлении,
-- вычисляется автоматически (+1), доступен только для чтения при редактировании.
-- article — артикул из импорта (атрибут, не ключ; в форме не редактируется).

CREATE TABLE product (
    product_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    article         TEXT,
    name            TEXT    NOT NULL,
    unit_id         INTEGER NOT NULL,
    price           REAL    NOT NULL DEFAULT 0 CHECK (price >= 0),
    supplier_id     INTEGER NOT NULL,
    manufacturer_id INTEGER NOT NULL,
    category_id     INTEGER NOT NULL,
    discount        INTEGER NOT NULL DEFAULT 0 CHECK (discount BETWEEN 0 AND 100),
    stock_quantity  INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    description     TEXT,
    photo           TEXT,
    FOREIGN KEY (unit_id)         REFERENCES unit(unit_id),
    FOREIGN KEY (supplier_id)     REFERENCES supplier(supplier_id),
    FOREIGN KEY (manufacturer_id) REFERENCES manufacturer(manufacturer_id),
    FOREIGN KEY (category_id)     REFERENCES category(category_id)
);

-- -------------------------- Заказы -----------------------------------

CREATE TABLE customer_order (
    order_id        INTEGER PRIMARY KEY,
    order_date      TEXT,            -- ISO 'YYYY-MM-DD' или NULL (некорректные данные)
    delivery_date   TEXT,
    pickup_point_id INTEGER,
    user_id         INTEGER,
    pickup_code     INTEGER,
    status_id       INTEGER NOT NULL,
    FOREIGN KEY (pickup_point_id) REFERENCES pickup_point(pickup_point_id),
    FOREIGN KEY (user_id)         REFERENCES app_user(user_id),
    FOREIGN KEY (status_id)       REFERENCES order_status(status_id)
);

-- Позиции заказа — результат нормализации поля «Артикул заказа»
-- ("А112Т4, 2, G843H5, 2"  ->  две строки: товар + количество).
CREATE TABLE order_item (
    order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL,
    product_id    INTEGER NOT NULL,
    quantity      INTEGER NOT NULL CHECK (quantity > 0),
    FOREIGN KEY (order_id)   REFERENCES customer_order(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES product(product_id)
);

-- Индексы под частые выборки
CREATE INDEX idx_product_category ON product(category_id);
CREATE INDEX idx_product_supplier ON product(supplier_id);
CREATE INDEX idx_order_item_order ON order_item(order_id);
CREATE INDEX idx_order_item_prod  ON order_item(product_id);
