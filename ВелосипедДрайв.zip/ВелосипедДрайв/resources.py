"""Пути к ресурсам и загрузка изображений (с картинкой-заглушкой)."""

import os
from PyQt5.QtGui import QPixmap

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RES_DIR = os.path.join(BASE_DIR, "resources")
IMAGES_DIR = os.path.join(RES_DIR, "images")

PLACEHOLDER = os.path.join(IMAGES_DIR, "picture.png")  # заглушка при отсутствии фото
LOGO = os.path.join(IMAGES_DIR, "icon.png")            # логотип компании
APP_ICON = os.path.join(IMAGES_DIR, "icon.ico")        # иконка приложения
STYLE = os.path.join(BASE_DIR, "styles.qss")


def product_image_path(photo_name):
    """Полный путь к фото товара. Если файла нет — путь к заглушке."""
    if photo_name:
        candidate = os.path.join(IMAGES_DIR, photo_name)
        if os.path.exists(candidate):
            return candidate
        # подстраховка по регистру (1.JPG / 1.jpg)
        for f in os.listdir(IMAGES_DIR):
            if f.lower() == photo_name.lower():
                return os.path.join(IMAGES_DIR, f)
    return PLACEHOLDER


def load_pixmap(photo_name, width, height):
    """QPixmap фото товара, масштабированный с сохранением пропорций."""
    from PyQt5.QtCore import Qt
    path = product_image_path(photo_name)
    pix = QPixmap(path)
    if pix.isNull():
        pix = QPixmap(PLACEHOLDER)
    return pix.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation)


def load_stylesheet():
    if os.path.exists(STYLE):
        with open(STYLE, encoding="utf-8") as f:
            return f.read()
    return ""
