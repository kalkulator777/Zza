"""
Импорт данных заказчика (файлы с пометкой import) в базу данных shop.db.

Что делает:
  * создаёт БД по schema.sql;
  * чистит «грязные» данные (лишние пробелы, регистр имён фото);
  * хеширует пароли (sha256) — в БД не хранится открытый пароль;
  * конвертирует Excel-сериалы дат в ISO; некорректные даты -> NULL;
  * нормализует поле «Артикул заказа» в таблицу order_item (3НФ);
  * копирует фото товаров в resources/images.

Запуск:  python import_data.py [путь_к_папке_import]
"""

import os
import sys
import shutil
import sqlite3
import hashlib
from datetime import datetime, timedelta

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "shop.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")
IMAGES_DIR = os.path.join(BASE_DIR, "resources", "images")

# Папка с файлами импорта (по умолчанию ./import рядом со скриптом)
IMPORT_DIR = sys.argv[1] if len(sys.argv) > 1 else os.path.join(BASE_DIR, "import")

EXCEL_EPOCH = datetime(1899, 12, 30)  # база Excel (с поправкой на «баг 1900 года»)


def hash_password(plain: str) -> str:
    """Хеш пароля. При логине сравнивается hash(введённого) с хешем из БД."""
    return hashlib.sha256(plain.encode("utf-8")).hexdigest()


def clean(value):
    """Убирает лишние пробелы по краям, NaN -> None."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    return str(value).strip()


def parse_date(value):
    """Timestamp / Excel-сериал / строка -> ISO-дата. Некорректная дата -> None."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    # pandas сам парсит корректные ячейки-даты в Timestamp/datetime
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.strftime("%Y-%m-%d")
    # Число -> сериал Excel (если ячейка хранится как число)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return (EXCEL_EPOCH + timedelta(days=int(value))).strftime("%Y-%m-%d")
        except (ValueError, OverflowError):
            return None
    # Строка вида dd.mm.yyyy (может содержать несуществующую дату, напр. 30.02.2023)
    text = str(value).strip()
    for fmt in ("%d.%m.%Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(text, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    print(f"  [!] Некорректная дата '{text}' -> NULL")
    return None


def get_or_create(cur, table, id_col, name):
    """Возвращает id справочной записи, создавая её при отсутствии."""
    name = clean(name) or "—"
    cur.execute(f"SELECT {id_col} FROM {table} WHERE name = ?", (name,))
    row = cur.fetchone()
    if row:
        return row[0]
    cur.execute(f"INSERT INTO {table}(name) VALUES (?)", (name,))
    return cur.lastrowid


def main():
    # --- создаём БД заново из схемы ---
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    with open(SCHEMA_PATH, encoding="utf-8") as f:
        conn.executescript(f.read())
    cur = conn.cursor()

    os.makedirs(IMAGES_DIR, exist_ok=True)

    # ================= ПУНКТЫ ВЫДАЧИ =================
    # Файл без заголовка: каждая строка — адрес. id = номер строки (1..N).
    pp = pd.read_excel(os.path.join(IMPORT_DIR, "Пункты_выдачи_import.xlsx"), header=None)
    for i, val in enumerate(pp.iloc[:, 0], start=1):
        addr = clean(val)
        if addr:
            cur.execute("INSERT INTO pickup_point(pickup_point_id, address) VALUES (?, ?)",
                        (i, addr))
    print(f"Пунктов выдачи: {cur.execute('SELECT COUNT(*) FROM pickup_point').fetchone()[0]}")

    # ================= ПОЛЬЗОВАТЕЛИ =================
    users = pd.read_excel(os.path.join(IMPORT_DIR, "user_import.xlsx"))
    name_to_user = {}
    for _, r in users.iterrows():
        role_id = get_or_create(cur, "role", "role_id", r["Роль сотрудника"])
        full_name = clean(r["ФИО"])
        login = clean(r["Логин"])
        pwd = clean(r["Пароль"])
        cur.execute(
            "INSERT INTO app_user(role_id, full_name, login, password_hash) VALUES (?,?,?,?)",
            (role_id, full_name, login, hash_password(pwd)))
        name_to_user[full_name] = cur.lastrowid
    print(f"Пользователей: {len(name_to_user)} (пароли захешированы)")

    # ================= ТОВАРЫ =================
    tovar = pd.read_excel(os.path.join(IMPORT_DIR, "Tovar.xlsx"))
    article_to_product = {}
    for _, r in tovar.iterrows():
        unit_id = get_or_create(cur, "unit", "unit_id", r["Единица измерения"])
        supplier_id = get_or_create(cur, "supplier", "supplier_id", r["Поставщик"])
        manuf_id = get_or_create(cur, "manufacturer", "manufacturer_id", r["Производитель"])
        cat_id = get_or_create(cur, "category", "category_id", r["Категория товара"])

        article = clean(r["Артикул"])
        photo = clean(r["Фото"])
        if photo:
            photo = photo.lower()  # '1.JPG' и '1.jpg' -> единый регистр

        cur.execute("""
            INSERT INTO product(article, name, unit_id, price, supplier_id,
                                manufacturer_id, category_id, discount,
                                stock_quantity, description, photo)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (article, clean(r["Наименование товара"]), unit_id,
             float(r["Цена"]), supplier_id, manuf_id, cat_id,
             int(r["Действующая скидка"]), int(r["Кол-во на складе"]),
             clean(r["Описание товара"]), photo))
        article_to_product[article] = cur.lastrowid
    print(f"Товаров: {len(article_to_product)}")

    # ================= ЗАКАЗЫ =================
    orders = pd.read_excel(os.path.join(IMPORT_DIR, "Заказ_import.xlsx"))
    items_total = 0
    for _, r in orders.iterrows():
        order_id = int(r["Номер заказа"])
        status_id = get_or_create(cur, "order_status", "status_id", r["Статус заказа"])

        # пункт выдачи — номер строки в справочнике
        pp_raw = clean(r["Адрес пункта выдачи"])
        pickup_id = int(float(pp_raw)) if pp_raw else None

        user_id = name_to_user.get(clean(r["ФИО авторизированного клиента"]))

        cur.execute("""
            INSERT INTO customer_order(order_id, order_date, delivery_date,
                                       pickup_point_id, user_id, pickup_code, status_id)
            VALUES (?,?,?,?,?,?,?)""",
            (order_id, parse_date(r["Дата заказа"]), parse_date(r["Дата доставки"]),
             pickup_id, user_id,
             int(r["Код для получения"]) if not pd.isna(r["Код для получения"]) else None,
             status_id))

        # нормализация «Артикул заказа»: "А112Т4, 2, G843H5, 2" -> позиции
        parts = [p.strip() for p in str(r["Артикул заказа"]).split(",") if p.strip()]
        for k in range(0, len(parts) - 1, 2):
            art, qty = parts[k], parts[k + 1]
            product_id = article_to_product.get(art)
            if product_id and qty.isdigit():
                cur.execute(
                    "INSERT INTO order_item(order_id, product_id, quantity) VALUES (?,?,?)",
                    (order_id, product_id, int(qty)))
                items_total += 1
    print(f"Заказов: {len(orders)}, позиций заказа: {items_total}")

    # ================= ФОТО =================
    copied = 0
    if os.path.isdir(IMPORT_DIR):
        for fname in os.listdir(IMPORT_DIR):
            low = fname.lower()
            if low.endswith((".jpg", ".jpeg", ".png")):
                shutil.copy(os.path.join(IMPORT_DIR, fname),
                            os.path.join(IMAGES_DIR, low))
                copied += 1
    print(f"Скопировано изображений: {copied}")

    conn.commit()
    conn.close()
    print(f"\nГотово. База: {DB_PATH}")


if __name__ == "__main__":
    main()
