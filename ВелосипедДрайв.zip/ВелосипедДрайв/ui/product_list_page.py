"""Страница со списком товаров (с учётом роли пользователя)."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox,
    QPushButton, QScrollArea, QMessageBox
)
from PyQt5.QtCore import Qt

import database as db
from database import ROLE_ADMIN, ROLE_MANAGER
from ui.product_card import ProductCard
from ui.product_edit_dialog import ProductEditDialog

# Варианты сортировки: текст -> (поле, по убыванию)
SORT_OPTIONS = [
    ("Без сортировки", (None, False)),
    ("Цена ↑", ("price", False)),
    ("Цена ↓", ("price", True)),
    ("Кол-во на складе ↑", ("stock_quantity", False)),
    ("Кол-во на складе ↓", ("stock_quantity", True)),
    ("Скидка ↑", ("discount", False)),
    ("Скидка ↓", ("discount", True)),
]

# Диапазоны фильтра по скидке: текст -> (low, high) | None
FILTER_OPTIONS = [
    ("Все диапазоны", None),
    ("0–11,99%", (0, 12)),
    ("12–18,99%", (12, 19)),
    ("19% и более", (19, None)),
]


class ProductListPage(QWidget):
    def __init__(self, user, on_open_orders=None):
        super().__init__()
        self.user = user
        self.role = user["role"] if user else None
        self.can_tools = self.role in (ROLE_ADMIN, ROLE_MANAGER)   # поиск/сортировка/фильтр
        self.can_edit = self.role == ROLE_ADMIN
        self.can_orders = self.role in (ROLE_ADMIN, ROLE_MANAGER)
        self.on_open_orders = on_open_orders
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)

        title = QLabel("Каталог товаров")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        # --- панель инструментов (только менеджер/администратор) ---
        if self.can_tools:
            tools = QHBoxLayout()

            self.search_edit = QLineEdit()
            self.search_edit.setPlaceholderText("Поиск по всем полям…")
            self.search_edit.textChanged.connect(self.refresh)   # в реальном времени
            tools.addWidget(self.search_edit, stretch=2)

            tools.addWidget(QLabel("Сортировка:"))
            self.sort_combo = QComboBox()
            for text, _ in SORT_OPTIONS:
                self.sort_combo.addItem(text)
            self.sort_combo.currentIndexChanged.connect(self.refresh)
            tools.addWidget(self.sort_combo, stretch=1)

            tools.addWidget(QLabel("Скидка:"))
            self.filter_combo = QComboBox()
            for text, _ in FILTER_OPTIONS:
                self.filter_combo.addItem(text)
            self.filter_combo.currentIndexChanged.connect(self.refresh)
            tools.addWidget(self.filter_combo, stretch=1)

            root.addLayout(tools)

        # --- кнопки действий ---
        actions = QHBoxLayout()
        if self.can_edit:
            btn_add = QPushButton("Добавить товар")
            btn_add.clicked.connect(self.add_product)
            actions.addWidget(btn_add)
        if self.can_orders and self.on_open_orders:
            btn_orders = QPushButton("Заказы")
            btn_orders.setObjectName("secondary")
            btn_orders.clicked.connect(self.on_open_orders)
            actions.addWidget(btn_orders)
        actions.addStretch()
        self.count_label = QLabel()
        actions.addWidget(self.count_label)
        root.addLayout(actions)

        # --- прокручиваемый список карточек ---
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.cards_host = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setAlignment(Qt.AlignTop)
        self.cards_layout.setSpacing(10)
        self.scroll.setWidget(self.cards_host)
        root.addWidget(self.scroll, stretch=1)

    def _current_params(self):
        search, sort_field, sort_desc, drange = "", None, False, None
        if self.can_tools:
            search = self.search_edit.text()
            sort_field, sort_desc = SORT_OPTIONS[self.sort_combo.currentIndex()][1]
            drange = FILTER_OPTIONS[self.filter_combo.currentIndex()][1]
        return search, sort_field, sort_desc, drange

    def refresh(self):
        # очистка списка
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        search, sort_field, sort_desc, drange = self._current_params()
        try:
            products = db.get_products(search, sort_field, sort_desc, drange)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить товары:\n{e}")
            return

        for p in products:
            card = ProductCard(p, clickable=self.can_edit, deletable=self.can_edit)
            if self.can_edit:
                card.clicked.connect(self.edit_product)
                card.delete_requested.connect(self.delete_product)
            self.cards_layout.addWidget(card)

        self.count_label.setText(f"Найдено: {len(products)}")

    # --- CRUD (только администратор) ---

    def add_product(self):
        dlg = ProductEditDialog(self, product_id=None)
        if dlg.exec_():           # модальность не даёт открыть второе окно редактирования
            self.refresh()

    def edit_product(self, product_id):
        dlg = ProductEditDialog(self, product_id=product_id)
        if dlg.exec_():
            self.refresh()

    def delete_product(self, product_id):
        product = db.get_product(product_id)
        if not product:
            return
        # предупреждение о неотвратимой операции
        confirm = QMessageBox.question(
            self, "Подтверждение удаления",
            f"Удалить товар «{product['name']}»?\nЭто действие необратимо.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if confirm != QMessageBox.Yes:
            return
        # товар из заказа удалить нельзя
        if db.product_in_orders(product_id):
            QMessageBox.warning(
                self, "Удаление невозможно",
                "Этот товар присутствует в одном или нескольких заказах "
                "и не может быть удалён.\nСначала удалите связанные заказы.")
            return
        try:
            db.delete_product(product_id)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось удалить товар:\n{e}")
            return
        QMessageBox.information(self, "Информация", "Товар удалён.")
        self.refresh()
