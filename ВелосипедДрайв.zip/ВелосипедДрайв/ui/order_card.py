"""Карточка одного заказа (по макету модуля 4)."""

from PyQt5.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QSizePolicy, QPushButton
from PyQt5.QtCore import Qt, pyqtSignal


class OrderCard(QFrame):
    clicked = pyqtSignal(int)           # клик по карточке -> редактирование
    delete_requested = pyqtSignal(int)  # кнопка «Удалить»

    def __init__(self, order, clickable=False, deletable=False):
        super().__init__()
        self.order = order
        self.order_id = order["order_id"]
        self.clickable = clickable
        self.deletable = deletable
        self.setObjectName("card")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        if clickable:
            self.setCursor(Qt.PointingHandCursor)
        self._build_ui()

    def _build_ui(self):
        o = self.order
        root = QHBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 10)
        root.setSpacing(12)

        # --- основной блок (артикул, статус, адрес, дата заказа) ---
        info = QVBoxLayout()
        info.setSpacing(3)

        articles = o["articles"] or "—"
        title = QLabel(f"Артикул заказа: {articles}")
        title.setObjectName("cardTitle")
        title.setWordWrap(True)
        info.addWidget(title)

        info.addWidget(QLabel(f"Статус заказа: {o['status']}"))
        info.addWidget(QLabel(f"Адрес пункта выдачи: {o['pickup_address'] or '—'}"))
        info.addWidget(QLabel(f"Дата заказа: {o['order_date'] or 'не указана'}"))
        root.addLayout(info, stretch=1)

        # --- блок «Дата доставки» справа ---
        right_col = QVBoxLayout()
        delivery = QLabel(f"Дата доставки:\n{o['delivery_date'] or 'не указана'}")
        delivery.setObjectName("discountBox")     # переиспользуем стиль рамки-блока
        delivery.setAlignment(Qt.AlignCenter)
        delivery.setFixedWidth(140)
        delivery.setMinimumHeight(60)
        right_col.addWidget(delivery)

        if self.deletable:
            btn_del = QPushButton("Удалить")
            btn_del.setObjectName("danger")
            btn_del.setFixedWidth(140)
            btn_del.clicked.connect(lambda: self.delete_requested.emit(self.order_id))
            right_col.addWidget(btn_del)
        right_col.addStretch()
        root.addLayout(right_col)

    def mousePressEvent(self, event):
        if self.clickable and event.button() == Qt.LeftButton:
            self.clicked.emit(self.order_id)
        super().mousePressEvent(event)
