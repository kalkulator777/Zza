"""Карточка одного товара (по макету из задания)."""

from PyQt5.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QSizePolicy, QPushButton
from PyQt5.QtCore import Qt, pyqtSignal

import resources

# Цвета по руководству по стилю / заданию
COLOR_DISCOUNT_BG = "#483D8B"   # скидка > 15%
COLOR_OUT_OF_STOCK = "#C0C0C0"  # нет на складе — серый


class ProductCard(QFrame):
    clicked = pyqtSignal(int)          # клик по карточке -> редактирование
    delete_requested = pyqtSignal(int)  # кнопка «Удалить»

    def __init__(self, product, clickable=False, deletable=False):
        super().__init__()
        self.product = product
        self.product_id = product["product_id"]
        self.clickable = clickable
        self.deletable = deletable
        self.setObjectName("card")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        if clickable:
            self.setCursor(Qt.PointingHandCursor)
        self._build_ui()
        self._apply_highlight()

    def _build_ui(self):
        p = self.product
        root = QHBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(12)

        # --- фото (заглушка при отсутствии) ---
        photo = QLabel()
        photo.setFixedSize(120, 100)
        photo.setAlignment(Qt.AlignCenter)
        photo.setPixmap(resources.load_pixmap(p["photo"], 120, 100))
        root.addWidget(photo)

        # --- средний блок с информацией ---
        info = QVBoxLayout()
        info.setSpacing(2)

        self.title = QLabel(f"{p['category']} | {p['name']}")
        self.title.setObjectName("cardTitle")
        self.title.setWordWrap(True)
        info.addWidget(self.title)

        self.desc = QLabel(f"Описание: {p['description'] or '—'}")
        self.desc.setWordWrap(True)
        info.addWidget(self.desc)

        self.manuf = QLabel(f"Производитель: {p['manufacturer']}")
        info.addWidget(self.manuf)
        self.supplier = QLabel(f"Поставщик: {p['supplier']}")
        info.addWidget(self.supplier)

        # цена с учётом скидки
        self.price = QLabel(self._price_html(p["price"], p["discount"]))
        info.addWidget(self.price)

        self.unit = QLabel(f"Единица измерения: {p['unit']}")
        info.addWidget(self.unit)
        self.stock = QLabel(f"Количество на складе: {p['stock_quantity']}")
        info.addWidget(self.stock)

        root.addLayout(info, stretch=1)

        # --- блок «Действующая скидка» справа ---
        right_col = QVBoxLayout()
        self.discount_box = QLabel(f"Действующая\nскидка\n{p['discount']}%")
        self.discount_box.setObjectName("discountBox")
        self.discount_box.setAlignment(Qt.AlignCenter)
        self.discount_box.setFixedWidth(110)
        self.discount_box.setMinimumHeight(70)
        right_col.addWidget(self.discount_box)

        if self.deletable:
            btn_del = QPushButton("Удалить")
            btn_del.setObjectName("danger")
            btn_del.setFixedWidth(110)
            btn_del.clicked.connect(lambda: self.delete_requested.emit(self.product_id))
            right_col.addWidget(btn_del)
        right_col.addStretch()
        root.addLayout(right_col)

    def _price_html(self, price, discount):
        """Если есть скидка — старая цена перечёркнута красным, итоговая чёрным."""
        if discount and discount > 0:
            final = round(price * (1 - discount / 100), 2)
            return (f"Цена: <s style='color:red'>{price:.2f} ₽</s> "
                    f"<span style='color:black'><b>{final:.2f} ₽</b></span>")
        return f"Цена: <span style='color:black'><b>{price:.2f} ₽</b></span>"

    def _apply_highlight(self):
        """Подсветка карточки: нет на складе (серый) > скидка>15% (#483D8B) > обычная (белая)."""
        p = self.product
        if p["stock_quantity"] == 0:
            self.setStyleSheet(
                f"QFrame#card {{ background: {COLOR_OUT_OF_STOCK}; border:1px solid #a0a0a0; border-radius:8px; }}"
                f"QFrame#card QLabel {{ color:#202020; }}"
                f"QFrame#card QLabel#discountBox {{ background:#808080; color:#ffffff; border-radius:6px; }}")
        elif p["discount"] > 15:
            self.setStyleSheet(
                f"QFrame#card {{ background: {COLOR_DISCOUNT_BG}; border:1px solid #2f2766; border-radius:8px; }}"
                f"QFrame#card QLabel {{ color:#ffffff; }}"
                f"QFrame#card QLabel#discountBox {{ background:#ffffff; color:{COLOR_DISCOUNT_BG}; border-radius:6px; }}")
            # «Цена:» наследует белый, но значения остаются red/black по заданию (см. _price_html)
        # обычная карточка использует глобальный стиль QFrame#card

    def mousePressEvent(self, event):
        if self.clickable and event.button() == Qt.LeftButton:
            self.clicked.emit(self.product_id)
        super().mousePressEvent(event)
