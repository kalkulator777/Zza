"""Главное окно приложения: шапка с ФИО и выходом, переключение страниц."""

from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QStackedWidget
)
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import Qt, pyqtSignal

import resources
from database import ROLE_ADMIN, ROLE_MANAGER, ROLE_CLIENT
from ui.product_list_page import ProductListPage
from ui.orders_page import OrdersPage

# Понятное название роли для шапки (гость = None)
ROLE_TITLE = {
    ROLE_ADMIN: "Администратор",
    ROLE_MANAGER: "Менеджер",
    ROLE_CLIENT: "Авторизированный клиент",
}


class MainWindow(QMainWindow):
    logout_requested = pyqtSignal()    # запрос на выход -> снова окно входа

    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user["role"] if user else None
        role_name = ROLE_TITLE.get(self.role, "Гость")

        self.setWindowTitle(f"ВелосипедДрайв — каталог ({role_name})")
        self.setWindowIcon(QIcon(resources.APP_ICON))
        self.resize(900, 640)
        self._build_ui(role_name)

    def _build_ui(self, role_name):
        central = QWidget()
        central.setObjectName("root")
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # --- шапка ---
        header = QFrame()
        header.setObjectName("header")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(16, 8, 16, 8)

        logo = QLabel()
        logo.setPixmap(QPixmap(resources.LOGO).scaled(
            40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        hl.addWidget(logo)

        company = QLabel("ООО «ВелосипедДрайв»")
        company.setObjectName("headerTitle")
        hl.addWidget(company)
        hl.addStretch()

        # ФИО пользователя в правом верхнем углу (по заданию)
        full_name = self.user["full_name"] if self.user else "Гость"
        user_label = QLabel(f"{full_name}  ·  {role_name}")
        user_label.setObjectName("headerUser")
        hl.addWidget(user_label)

        btn_logout = QPushButton("Выход")
        btn_logout.setObjectName("secondary")
        btn_logout.clicked.connect(self.logout_requested.emit)
        hl.addWidget(btn_logout)

        root.addWidget(header)

        # --- переключаемые страницы ---
        self.stack = QStackedWidget()
        self.products_page = ProductListPage(self.user, on_open_orders=self.show_orders)
        self.stack.addWidget(self.products_page)

        # страница заказов доступна только менеджеру/администратору
        self.orders_page = None
        if self.role in (ROLE_ADMIN, ROLE_MANAGER):
            self.orders_page = OrdersPage(self.user, on_back=self.show_products)
            self.stack.addWidget(self.orders_page)

        root.addWidget(self.stack, stretch=1)
        self.setCentralWidget(central)

    def show_orders(self):
        if self.orders_page is not None:
            self.orders_page.refresh()
            self.stack.setCurrentWidget(self.orders_page)

    def show_products(self):
        self.products_page.refresh()
        self.stack.setCurrentWidget(self.products_page)
