"""Форма добавления / редактирования товара (модальное окно)."""

import os
import time

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QComboBox, QPlainTextEdit, QDoubleSpinBox, QSpinBox, QPushButton,
    QMessageBox, QFileDialog, QWidget
)
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import Qt

from PIL import Image

import resources
import database as db

MAX_W, MAX_H = 300, 200  # ограничение размера фото


class ProductEditDialog(QDialog):
    def __init__(self, parent=None, product_id=None):
        super().__init__(parent)
        self.product_id = product_id          # None -> добавление
        self.is_edit = product_id is not None
        self.product = db.get_product(product_id) if self.is_edit else None
        self.photo = self.product["photo"] if self.is_edit else None
        self.original_photo = self.photo
        self.new_image_source = None          # путь к выбранному, но ещё не сохранённому фото

        self.setWindowTitle("Редактирование товара" if self.is_edit else "Добавление товара")
        self.setWindowIcon(QIcon(resources.APP_ICON))
        self.setModal(True)
        self.setMinimumWidth(560)
        self._build_ui()
        if self.is_edit:
            self._fill_fields()

    def _build_ui(self):
        root = QVBoxLayout(self)
        top = QHBoxLayout()

        # --- фото слева ---
        photo_col = QVBoxLayout()
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(200, 150)
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setStyleSheet("border:1px solid #c4b8e0; border-radius:5px;")
        self.photo_label.setPixmap(resources.load_pixmap(self.photo, 200, 150))
        photo_col.addWidget(self.photo_label)
        btn_photo = QPushButton("Выбрать фото…")
        btn_photo.setObjectName("secondary")
        btn_photo.clicked.connect(self.choose_image)
        photo_col.addWidget(btn_photo)
        photo_col.addStretch()
        top.addLayout(photo_col)

        # --- поля справа ---
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)

        self.id_label = QLabel(str(self.product_id) if self.is_edit else f"{db.next_product_id()} (новый)")
        if self.is_edit:
            form.addRow("ID товара:", self.id_label)  # при добавлении ID не показываем (по заданию)

        self.name_edit = QLineEdit()
        form.addRow("Наименование*:", self.name_edit)

        self.category_combo = QComboBox()
        for _id, name in db.get_categories():
            self.category_combo.addItem(name)
        form.addRow("Категория*:", self.category_combo)

        self.desc_edit = QPlainTextEdit()
        self.desc_edit.setFixedHeight(60)
        form.addRow("Описание:", self.desc_edit)

        self.manuf_edit = QLineEdit()
        form.addRow("Производитель:", self.manuf_edit)

        self.supplier_combo = QComboBox()
        for _id, name in db.get_suppliers():
            self.supplier_combo.addItem(name)
        form.addRow("Поставщик*:", self.supplier_combo)

        self.price_spin = QDoubleSpinBox()
        self.price_spin.setRange(0, 10_000_000)   # не может быть отрицательной
        self.price_spin.setDecimals(2)             # сотые части
        self.price_spin.setSuffix(" ₽")
        form.addRow("Цена*:", self.price_spin)

        self.unit_edit = QLineEdit()
        self.unit_edit.setText("шт.")
        form.addRow("Ед. измерения:", self.unit_edit)

        self.stock_spin = QSpinBox()
        self.stock_spin.setRange(0, 1_000_000)     # не может быть отрицательным
        form.addRow("Кол-во на складе:", self.stock_spin)

        self.discount_spin = QSpinBox()
        self.discount_spin.setRange(0, 100)
        self.discount_spin.setSuffix(" %")
        form.addRow("Действующая скидка:", self.discount_spin)

        right = QWidget()
        right.setLayout(form)
        top.addWidget(right, stretch=1)
        root.addLayout(top)

        # --- кнопки ---
        buttons = QHBoxLayout()
        buttons.addStretch()
        btn_cancel = QPushButton("Отмена")
        btn_cancel.setObjectName("secondary")
        btn_cancel.clicked.connect(self.reject)
        buttons.addWidget(btn_cancel)
        btn_save = QPushButton("Сохранить")
        btn_save.clicked.connect(self.save)
        buttons.addWidget(btn_save)
        root.addLayout(buttons)

    def _fill_fields(self):
        p = self.product
        self.name_edit.setText(p["name"])
        self.category_combo.setCurrentText(p["category"])
        self.desc_edit.setPlainText(p["description"] or "")
        self.manuf_edit.setText(p["manufacturer"])
        self.supplier_combo.setCurrentText(p["supplier"])
        self.price_spin.setValue(p["price"])
        self.unit_edit.setText(p["unit"])
        self.stock_spin.setValue(p["stock_quantity"])
        self.discount_spin.setValue(p["discount"])

    def choose_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите изображение товара", "",
            "Изображения (*.png *.jpg *.jpeg *.bmp)")
        if not path:
            return
        try:
            # предпросмотр напрямую из выбранного файла
            self.photo_label.setPixmap(
                QPixmap(path).scaled(200, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            self.new_image_source = path
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось открыть изображение:\n{e}")

    def _commit_image(self):
        """Сжимает выбранное фото до 300×200, сохраняет в resources/images,
        удаляет старый файл. Возвращает имя нового файла."""
        if not self.new_image_source:
            return self.photo
        img = Image.open(self.new_image_source).convert("RGB")
        img.thumbnail((MAX_W, MAX_H))           # не более 300×200, пропорции сохраняются
        new_name = f"product_{int(time.time() * 1000)}.png"
        img.save(os.path.join(resources.IMAGES_DIR, new_name))
        # удалить старый файл (но не заглушку и не общие импортные фото вида N.jpg)
        if (self.original_photo and self.original_photo != "picture.png"
                and self.original_photo.startswith("product_")):
            old = os.path.join(resources.IMAGES_DIR, self.original_photo)
            if os.path.exists(old):
                os.remove(old)
        return new_name

    def save(self):
        # --- валидация ---
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Предупреждение",
                                "Поле «Наименование» не может быть пустым.\nВведите название товара.")
            self.name_edit.setFocus()
            return
        if self.price_spin.value() < 0 or self.stock_spin.value() < 0:
            QMessageBox.warning(self, "Предупреждение",
                                "Цена и количество не могут быть отрицательными.")
            return

        try:
            photo = self._commit_image()
            data = {
                "name": name,
                "category": self.category_combo.currentText(),
                "supplier": self.supplier_combo.currentText(),
                "manufacturer": self.manuf_edit.text().strip(),
                "unit": self.unit_edit.text().strip() or "шт.",
                "price": round(self.price_spin.value(), 2),
                "discount": self.discount_spin.value(),
                "stock_quantity": self.stock_spin.value(),
                "description": self.desc_edit.toPlainText().strip(),
                "photo": photo,
            }
            if self.is_edit:
                db.update_product(self.product_id, data)
            else:
                db.add_product(data)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить товар:\n{e}")
            return

        QMessageBox.information(self, "Информация", "Товар успешно сохранён.")
        self.accept()
