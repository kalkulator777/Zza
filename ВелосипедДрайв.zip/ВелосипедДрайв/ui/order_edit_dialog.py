"""Форма добавления / редактирования заказа (модальное окно, модуль 4)."""

import re

from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QComboBox, QPushButton, QMessageBox, QDateEdit, QCheckBox, QWidget
)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt, QDate

import resources
import database as db


def parse_articles(text):
    """'А112Т4×2, G843H5' -> [('А112Т4', 2), ('G843H5', 1)].

    Количество отделяется знаками ×, x, х, * (по умолчанию 1).
    """
    items = []
    for chunk in text.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        m = re.match(r"^(.*?)\s*[×xXхХ*]\s*(\d+)$", chunk)
        if m:
            article, qty = m.group(1).strip(), int(m.group(2))
        else:
            article, qty = chunk, 1
        if article:
            items.append((article, max(1, qty)))
    return items


class OrderEditDialog(QDialog):
    def __init__(self, parent=None, order=None):
        super().__init__(parent)
        self.order = order                       # dict из get_orders() или None
        self.is_edit = order is not None
        self.order_id = order["order_id"] if self.is_edit else None

        self.setWindowTitle("Редактирование заказа" if self.is_edit else "Добавление заказа")
        self.setWindowIcon(QIcon(resources.APP_ICON))
        self.setModal(True)
        self.setMinimumWidth(520)
        self._build_ui()
        if self.is_edit:
            self._fill_fields()

    def _build_ui(self):
        root = QVBoxLayout(self)
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)

        # ID показываем только при редактировании (как у товаров)
        if self.is_edit:
            form.addRow("Номер заказа:", QLabel(str(self.order_id)))
        else:
            form.addRow("Номер заказа:", QLabel(f"{db.next_order_id()} (новый)"))

        # Артикул — позиции заказа в текстовом виде
        self.article_edit = QLineEdit()
        self.article_edit.setPlaceholderText("Напр.: А112Т4×2, G843H5×1")
        form.addRow("Артикул*:", self.article_edit)
        hint = QLabel("Несколько артикулов — через запятую, количество — после знака ×")
        hint.setStyleSheet("color:#6A5ACD; font-size:11px;")
        form.addRow("", hint)

        # Статус заказа — выпадающий список
        self.status_combo = QComboBox()
        self.statuses = db.get_order_statuses()        # [(id, name), ...]
        for _id, name in self.statuses:
            self.status_combo.addItem(name)
        form.addRow("Статус заказа*:", self.status_combo)

        # Адрес пункта выдачи — выпадающий список (ссылочная целостность)
        self.pickup_combo = QComboBox()
        self.pickups = db.get_pickup_points()          # [(id, address), ...]
        for _id, address in self.pickups:
            self.pickup_combo.addItem(address)
        form.addRow("Адрес пункта выдачи*:", self.pickup_combo)

        # Дата заказа (может отсутствовать)
        self.order_date_edit, order_date_row = self._date_field()
        form.addRow("Дата заказа:", order_date_row)

        # Дата выдачи (может отсутствовать)
        self.delivery_date_edit, delivery_date_row = self._date_field()
        form.addRow("Дата выдачи:", delivery_date_row)

        host = QWidget()
        host.setLayout(form)
        root.addWidget(host)

        buttons = QHBoxLayout()
        buttons.addStretch()
        btn_cancel = QPushButton("Отмена")
        btn_cancel.setObjectName("secondary")
        btn_cancel.clicked.connect(self.reject)
        buttons.addWidget(btn_cancel)
        btn_save = QPushButton("Сохранить")
        btn_save.clicked.connect(self.save)
        buttons.addWidget(btn_save)
        root.addLayout(buttons)

    def _date_field(self):
        """QDateEdit + чекбокс «не указана». Возвращает (date_edit, контейнер)."""
        container = QWidget()
        lay = QHBoxLayout(container)
        lay.setContentsMargins(0, 0, 0, 0)
        date_edit = QDateEdit()
        date_edit.setCalendarPopup(True)
        date_edit.setDisplayFormat("dd.MM.yyyy")
        date_edit.setDate(QDate.currentDate())
        none_box = QCheckBox("не указана")
        none_box.toggled.connect(lambda checked: date_edit.setDisabled(checked))
        lay.addWidget(date_edit, stretch=1)
        lay.addWidget(none_box)
        date_edit.none_box = none_box     # держим ссылку для удобства
        return date_edit, container

    def _set_date(self, date_edit, iso_value):
        """Заполняет поле даты из строки 'YYYY-MM-DD' или ставит «не указана»."""
        if iso_value:
            qd = QDate.fromString(iso_value, "yyyy-MM-dd")
            if qd.isValid():
                date_edit.setDate(qd)
                date_edit.none_box.setChecked(False)
                return
        date_edit.none_box.setChecked(True)

    def _get_date(self, date_edit):
        """Возвращает 'YYYY-MM-DD' или None, если стоит «не указана»."""
        if date_edit.none_box.isChecked():
            return None
        return date_edit.date().toString("yyyy-MM-dd")

    def _fill_fields(self):
        o = self.order
        # позиции заказа -> текст «АРТ×КОЛ-ВО, …»
        items = db.get_order_items(self.order_id)
        self.article_edit.setText(", ".join(f"{art}×{qty}" for art, qty in items))
        self.status_combo.setCurrentText(o["status"])
        if o["pickup_address"]:
            self.pickup_combo.setCurrentText(o["pickup_address"])
        self._set_date(self.order_date_edit, o["order_date"])
        self._set_date(self.delivery_date_edit, o["delivery_date"])

    def save(self):
        # --- разбор и проверка артикулов ---
        raw = self.article_edit.text().strip()
        if not raw:
            QMessageBox.warning(self, "Предупреждение",
                                "Укажите хотя бы один артикул заказа.\n"
                                "Формат: АРТИКУЛ×КОЛИЧЕСТВО, через запятую.")
            self.article_edit.setFocus()
            return

        parsed = parse_articles(raw)
        items, unknown = [], []
        for article, qty in parsed:
            product_id = db.get_product_id_by_article(article)
            if product_id is None:
                unknown.append(article)
            else:
                items.append((product_id, qty))

        if unknown:
            QMessageBox.critical(
                self, "Ошибка",
                "Не найдены товары с артикулами:\n• " + "\n• ".join(unknown) +
                "\n\nПроверьте правильность ввода артикулов.")
            return
        if not items:
            QMessageBox.warning(self, "Предупреждение",
                                "Не удалось распознать ни одного артикула.")
            return

        status_id = self.statuses[self.status_combo.currentIndex()][0]
        pickup_id = self.pickups[self.pickup_combo.currentIndex()][0]

        data = {
            "status_id": status_id,
            "pickup_point_id": pickup_id,
            "order_date": self._get_date(self.order_date_edit),
            "delivery_date": self._get_date(self.delivery_date_edit),
            "items": items,
        }

        try:
            if self.is_edit:
                db.update_order(self.order_id, data)
            else:
                db.add_order(data)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить заказ:\n{e}")
            return

        QMessageBox.information(self, "Информация", "Заказ успешно сохранён.")
        self.accept()
