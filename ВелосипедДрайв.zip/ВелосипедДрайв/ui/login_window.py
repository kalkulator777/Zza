"""Окно входа — первое, что видит пользователь."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import Qt, pyqtSignal

import resources
import database as db


class LoginWindow(QWidget):
    # сигнал передаёт словарь пользователя или None (гость)
    login_success = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.setObjectName("root")
        self.setWindowTitle("ВелосипедДрайв — Вход в систему")
        self.setWindowIcon(QIcon(resources.APP_ICON))
        self.setFixedSize(420, 520)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 30, 40, 30)
        layout.setSpacing(14)

        # Логотип компании (не искажаем — KeepAspectRatio)
        logo = QLabel()
        logo.setAlignment(Qt.AlignCenter)
        logo.setPixmap(QPixmap(resources.LOGO).scaled(
            150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        layout.addWidget(logo)

        title = QLabel("ООО «ВелосипедДрайв»")
        title.setObjectName("pageTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        layout.addSpacing(10)
        layout.addWidget(QLabel("Логин"))
        self.login_edit = QLineEdit()
        self.login_edit.setPlaceholderText("Введите логин (e-mail)")
        layout.addWidget(self.login_edit)

        layout.addWidget(QLabel("Пароль"))
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("Введите пароль")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.returnPressed.connect(self.handle_login)
        layout.addWidget(self.password_edit)

        layout.addSpacing(10)
        btn_login = QPushButton("Войти")
        btn_login.clicked.connect(self.handle_login)
        layout.addWidget(btn_login)

        btn_guest = QPushButton("Войти как гость")
        btn_guest.setObjectName("secondary")
        btn_guest.clicked.connect(self.handle_guest)
        layout.addWidget(btn_guest)

        layout.addStretch()

    def handle_login(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text()

        # Обработка исключительных ситуаций: пустые поля
        if not login or not password:
            QMessageBox.warning(self, "Предупреждение",
                                "Введите логин и пароль.\nОба поля обязательны для заполнения.")
            return

        try:
            user = db.authenticate(login, password)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка",
                                 f"Не удалось обратиться к базе данных:\n{e}")
            return

        if user is None:
            QMessageBox.critical(self, "Ошибка",
                                 "Неверный логин или пароль.\nПроверьте правильность ввода и повторите попытку.")
            self.password_edit.clear()
            self.password_edit.setFocus()
            return

        self.password_edit.clear()
        self.login_success.emit(user)

    def handle_guest(self):
        # Гость: доступ только к просмотру товаров без фильтрации/сортировки/поиска
        self.login_success.emit(None)
