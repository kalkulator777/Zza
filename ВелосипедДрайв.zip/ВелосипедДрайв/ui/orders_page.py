"""Страница со списком заказов (модуль 4)."""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QMessageBox
)
from PyQt5.QtCore import Qt

import database as db
from database import ROLE_ADMIN
from ui.order_card import OrderCard
from ui.order_edit_dialog import OrderEditDialog


class OrdersPage(QWidget):
    def __init__(self, user, on_back=None):
        super().__init__()
        self.user = user
        self.role = user["role"] if user else None
        self.can_edit = self.role == ROLE_ADMIN      # add/edit/delete только администратор
        self.on_back = on_back
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)

        # --- верхняя панель: «Назад» + заголовок ---
        top = QHBoxLayout()
        if self.on_back:
            btn_back = QPushButton("← Назад")
            btn_back.setObjectName("secondary")
            btn_back.clicked.connect(self.on_back)
            top.addWidget(btn_back)
        title = QLabel("Заказы")
        title.setObjectName("pageTitle")
        top.addWidget(title)
        top.addStretch()
        root.addLayout(top)

        # --- действия ---
        actions = QHBoxLayout()
        if self.can_edit:
            btn_add = QPushButton("Добавить заказ")
            btn_add.clicked.connect(self.add_order)
            actions.addWidget(btn_add)
        actions.addStretch()
        self.count_label = QLabel()
        actions.addWidget(self.count_label)
        root.addLayout(actions)

        # --- список карточек ---
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.cards_host = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setAlignment(Qt.AlignTop)
        self.cards_layout.setSpacing(10)
        self.scroll.setWidget(self.cards_host)
        root.addWidget(self.scroll, stretch=1)

    def refresh(self):
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        try:
            orders = db.get_orders()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить заказы:\n{e}")
            return

        for o in orders:
            card = OrderCard(o, clickable=self.can_edit, deletable=self.can_edit)
            if self.can_edit:
                card.clicked.connect(self.edit_order)
                card.delete_requested.connect(self.delete_order)
            self.cards_layout.addWidget(card)

        self.count_label.setText(f"Всего заказов: {len(orders)}")

    # --- CRUD (только администратор) ---

    def add_order(self):
        dlg = OrderEditDialog(self, order=None)
        if dlg.exec_():
            self.refresh()

    def edit_order(self, order_id):
        order = next((o for o in db.get_orders() if o["order_id"] == order_id), None)
        if not order:
            return
        dlg = OrderEditDialog(self, order=order)
        if dlg.exec_():
            self.refresh()

    def delete_order(self, order_id):
        confirm = QMessageBox.question(
            self, "Подтверждение удаления",
            f"Удалить заказ №{order_id}?\nЭто действие необратимо.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if confirm != QMessageBox.Yes:
            return
        try:
            db.delete_order(order_id)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось удалить заказ:\n{e}")
            return
        QMessageBox.information(self, "Информация", "Заказ удалён.")
        self.refresh()
