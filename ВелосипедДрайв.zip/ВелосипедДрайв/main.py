"""Точка входа приложения «ВелосипедДрайв»."""

import sys
import os

from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QIcon, QFont

import resources
from ui.login_window import LoginWindow
from ui.main_window import MainWindow


class Application:
    """Управляет переходами: окно входа <-> главное окно."""

    def __init__(self):
        self.login = None
        self.main = None

    def start(self):
        self.show_login()

    def show_login(self):
        # закрываем главное окно, если было
        if self.main is not None:
            self.main.close()
            self.main = None
        self.login = LoginWindow()
        self.login.login_success.connect(self.open_main)
        self.login.show()

    def open_main(self, user):
        # user — dict пользователя или None (гость)
        if self.login is not None:
            self.login.close()
            self.login = None
        self.main = MainWindow(user)
        self.main.logout_requested.connect(self.show_login)
        self.main.show()


def main():
    app = QApplication(sys.argv)

    # Единый шрифт по руководству по стилю (Arial)
    app.setFont(QFont("Arial", 10))

    # Иконка приложения
    if os.path.exists(resources.APP_ICON):
        app.setWindowIcon(QIcon(resources.APP_ICON))

    # Общая таблица стилей
    app.setStyleSheet(resources.load_stylesheet())

    controller = Application()
    controller.start()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
