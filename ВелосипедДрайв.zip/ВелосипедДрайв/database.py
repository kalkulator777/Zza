"""
Слой доступа к данным (DAL).
Всё взаимодействие с SQLite сосредоточено здесь — UI работает только с этими функциями.
"""

import os
import sqlite3
import hashlib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "shop.db")

# Названия ролей (как в БД)
ROLE_ADMIN = "Администратор"
ROLE_MANAGER = "Менеджер"
ROLE_CLIENT = "Авторизированный клиент"


def get_connection():
    """Новое подключение с включённой ссылочной целостностью."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def hash_password(plain):
    return hashlib.sha256(plain.encode("utf-8")).hexdigest()


# ============================ АУТЕНТИФИКАЦИЯ ============================

def authenticate(login, password):
    """Возвращает dict пользователя при успехе, иначе None."""
    conn = get_connection()
    row = conn.execute("""
        SELECT u.user_id, u.full_name, u.login, u.password_hash, r.name AS role
        FROM app_user u JOIN role r ON r.role_id = u.role_id
        WHERE u.login = ?""", (login,)).fetchone()
    conn.close()
    if row and row["password_hash"] == hash_password(password):
        return {"user_id": row["user_id"], "full_name": row["full_name"], "role": row["role"]}
    return None


# ============================ СПРАВОЧНИКИ ==============================

def get_reference(table, id_col):
    """Список (id, name) из справочной таблицы."""
    conn = get_connection()
    rows = conn.execute(f"SELECT {id_col} AS id, name FROM {table} ORDER BY name").fetchall()
    conn.close()
    return [(r["id"], r["name"]) for r in rows]


def get_categories():
    return get_reference("category", "category_id")


def get_suppliers():
    return get_reference("supplier", "supplier_id")


def get_units():
    return get_reference("unit", "unit_id")


def get_order_statuses():
    return get_reference("order_status", "status_id")


def get_pickup_points():
    conn = get_connection()
    rows = conn.execute(
        "SELECT pickup_point_id AS id, address FROM pickup_point ORDER BY pickup_point_id").fetchall()
    conn.close()
    return [(r["id"], r["address"]) for r in rows]


def _get_or_create(conn, table, id_col, name):
    """id справочной записи по имени (создаёт при отсутствии). Для text-полей формы."""
    name = (name or "").strip() or "—"
    row = conn.execute(f"SELECT {id_col} FROM {table} WHERE name = ?", (name,)).fetchone()
    if row:
        return row[0]
    cur = conn.execute(f"INSERT INTO {table}(name) VALUES (?)", (name,))
    return cur.lastrowid


# ============================== ТОВАРЫ ================================

PRODUCT_SELECT = """
    SELECT p.product_id, p.article, p.name, p.price, p.discount,
           p.stock_quantity, p.description, p.photo,
           c.name AS category, s.name AS supplier,
           m.name AS manufacturer, u.name AS unit,
           p.category_id, p.supplier_id, p.manufacturer_id, p.unit_id
    FROM product p
    JOIN category     c ON c.category_id     = p.category_id
    JOIN supplier     s ON s.supplier_id     = p.supplier_id
    JOIN manufacturer m ON m.manufacturer_id = p.manufacturer_id
    JOIN unit         u ON u.unit_id         = p.unit_id
"""


def get_products(search="", sort_field=None, sort_desc=False, discount_range=None):
    """
    Возвращает товары с учётом поиска, сортировки и фильтра.
      search          — строка поиска по всем текстовым полям;
      sort_field      — 'stock_quantity' | 'price' | 'discount' | None;
      sort_desc       — True для убывания;
      discount_range  — (low, high) в процентах, high=None означает «и более».
    """
    conn = get_connection()
    where, params = [], []

    if search:
        like = f"%{search.strip()}%"
        where.append("""(
            p.name LIKE ? OR p.article LIKE ? OR p.description LIKE ?
            OR c.name LIKE ? OR s.name LIKE ? OR m.name LIKE ? OR u.name LIKE ?
        )""")
        params += [like] * 7

    if discount_range is not None:
        low, high = discount_range
        if high is None:
            where.append("p.discount >= ?")
            params.append(low)
        else:
            where.append("p.discount >= ? AND p.discount < ?")
            params += [low, high]

    sql = PRODUCT_SELECT
    if where:
        sql += " WHERE " + " AND ".join(where)
    if sort_field in ("stock_quantity", "price", "discount"):
        sql += f" ORDER BY p.{sort_field} {'DESC' if sort_desc else 'ASC'}"
    else:
        sql += " ORDER BY p.product_id"

    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_product(product_id):
    conn = get_connection()
    row = conn.execute(PRODUCT_SELECT + " WHERE p.product_id = ?", (product_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def next_product_id():
    """ID нового товара = max(id) + 1 (для отображения логики «+1»)."""
    conn = get_connection()
    row = conn.execute("SELECT COALESCE(MAX(product_id), 0) + 1 AS nid FROM product").fetchone()
    conn.close()
    return row["nid"]


def add_product(data):
    """data: dict с ключами name, category, supplier, manufacturer, unit,
    price, discount, stock_quantity, description, photo. Возвращает product_id."""
    conn = get_connection()
    cat = _get_or_create(conn, "category", "category_id", data["category"])
    sup = _get_or_create(conn, "supplier", "supplier_id", data["supplier"])
    man = _get_or_create(conn, "manufacturer", "manufacturer_id", data["manufacturer"])
    unit = _get_or_create(conn, "unit", "unit_id", data["unit"])
    cur = conn.execute("""
        INSERT INTO product(name, category_id, supplier_id, manufacturer_id, unit_id,
                            price, discount, stock_quantity, description, photo)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (data["name"], cat, sup, man, unit, data["price"], data["discount"],
         data["stock_quantity"], data["description"], data["photo"]))
    pid = cur.lastrowid
    conn.commit()
    conn.close()
    return pid


def update_product(product_id, data):
    conn = get_connection()
    cat = _get_or_create(conn, "category", "category_id", data["category"])
    sup = _get_or_create(conn, "supplier", "supplier_id", data["supplier"])
    man = _get_or_create(conn, "manufacturer", "manufacturer_id", data["manufacturer"])
    unit = _get_or_create(conn, "unit", "unit_id", data["unit"])
    conn.execute("""
        UPDATE product SET name=?, category_id=?, supplier_id=?, manufacturer_id=?,
               unit_id=?, price=?, discount=?, stock_quantity=?, description=?, photo=?
        WHERE product_id=?""",
        (data["name"], cat, sup, man, unit, data["price"], data["discount"],
         data["stock_quantity"], data["description"], data["photo"], product_id))
    conn.commit()
    conn.close()


def product_in_orders(product_id):
    """True, если товар присутствует хотя бы в одном заказе (удалять нельзя)."""
    conn = get_connection()
    row = conn.execute(
        "SELECT 1 FROM order_item WHERE product_id = ? LIMIT 1", (product_id,)).fetchone()
    conn.close()
    return row is not None


def delete_product(product_id):
    conn = get_connection()
    conn.execute("DELETE FROM product WHERE product_id = ?", (product_id,))
    conn.commit()
    conn.close()


# ============================== ЗАКАЗЫ ===============================

def get_orders():
    """Заказы с собранной строкой позиций («Артикул заказа»), статусом и адресом."""
    conn = get_connection()
    orders = conn.execute("""
        SELECT o.order_id, o.order_date, o.delivery_date, o.pickup_code,
               st.name AS status, st.status_id,
               pp.address AS pickup_address, o.pickup_point_id,
               us.full_name AS client
        FROM customer_order o
        JOIN order_status st ON st.status_id = o.status_id
        LEFT JOIN pickup_point pp ON pp.pickup_point_id = o.pickup_point_id
        LEFT JOIN app_user us ON us.user_id = o.user_id
        ORDER BY o.order_id""").fetchall()

    result = []
    for o in orders:
        items = conn.execute("""
            SELECT p.article, oi.quantity FROM order_item oi
            JOIN product p ON p.product_id = oi.product_id
            WHERE oi.order_id = ?""", (o["order_id"],)).fetchall()
        article_str = ", ".join(f"{i['article']} ×{i['quantity']}" for i in items)
        d = dict(o)
        d["articles"] = article_str
        result.append(d)
    conn.close()
    return result


def next_order_id():
    conn = get_connection()
    row = conn.execute("SELECT COALESCE(MAX(order_id), 0) + 1 AS nid FROM customer_order").fetchone()
    conn.close()
    return row["nid"]


def get_order_items(order_id):
    """Позиции заказа: артикул + количество (для формы редактирования)."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT p.article, oi.quantity
        FROM order_item oi
        JOIN product p ON p.product_id = oi.product_id
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id""", (order_id,)).fetchall()
    conn.close()
    return [(r["article"], r["quantity"]) for r in rows]


def get_product_id_by_article(article):
    """ID товара по артикулу (без учёта регистра/пробелов, в т.ч. кириллица) или None."""
    target = (article or "").strip().casefold()
    if not target:
        return None
    conn = get_connection()
    rows = conn.execute("SELECT product_id, article FROM product").fetchall()
    conn.close()
    for r in rows:
        if (r["article"] or "").strip().casefold() == target:
            return r["product_id"]
    return None


def _sync_order_items(conn, order_id, items):
    """Перезаписывает позиции заказа. items: список (product_id, quantity)."""
    conn.execute("DELETE FROM order_item WHERE order_id = ?", (order_id,))
    for product_id, qty in items:
        conn.execute(
            "INSERT INTO order_item(order_id, product_id, quantity) VALUES (?,?,?)",
            (order_id, product_id, qty))


def add_order(data):
    """data: status_id, pickup_point_id, order_date, delivery_date, items."""
    conn = get_connection()
    oid = conn.execute(
        "SELECT COALESCE(MAX(order_id), 0) + 1 AS nid FROM customer_order").fetchone()["nid"]
    conn.execute("""
        INSERT INTO customer_order(order_id, status_id, pickup_point_id,
                                   order_date, delivery_date, pickup_code)
        VALUES (?,?,?,?,?,?)""",
        (oid, data["status_id"], data["pickup_point_id"],
         data["order_date"], data["delivery_date"], 900 + oid))
    if data.get("items") is not None:
        _sync_order_items(conn, oid, data["items"])
    conn.commit()
    conn.close()
    return oid


def update_order(order_id, data):
    conn = get_connection()
    conn.execute("""
        UPDATE customer_order
        SET status_id=?, pickup_point_id=?, order_date=?, delivery_date=?
        WHERE order_id=?""",
        (data["status_id"], data["pickup_point_id"],
         data["order_date"], data["delivery_date"], order_id))
    if data.get("items") is not None:
        _sync_order_items(conn, order_id, data["items"])
    conn.commit()
    conn.close()


def delete_order(order_id):
    conn = get_connection()
    conn.execute("DELETE FROM customer_order WHERE order_id = ?", (order_id,))  # позиции — ON DELETE CASCADE
    conn.commit()
    conn.close()
